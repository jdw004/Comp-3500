#include <stdio.h>

int
openFile(char *name, FILE **file_descriptor)
{
    // Try to open the file
    if (! (*file_descriptor = fopen(name, "r"))) {
        printf("File %s can't be opened. Please retry ...\n");
        return 1;
    }
    
    printf("Open file: %s\n", name);
    return 0;
}