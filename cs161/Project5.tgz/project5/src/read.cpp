#include <stdio.h>
#include "scheduler.h"


void
read_file(FILE *file_descriptor, task_t task_list[], u_int *size)
{
    // read data from input file
   int num = 0;
   while (fscanf(file_descriptor, "%u %u %u", &task_list[num].pid, &task_list[num].arrival_time, \
              &task_list[num].burst_time)!= EOF) {
        num++;
    }
    *size = num;

    //initialize remaining time as burst time 
    for (int i = 0; i < num; i++) {
        task_list[i].remaining_time = task_list[i].burst_time;
    }
}