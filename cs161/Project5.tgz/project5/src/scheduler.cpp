#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <queue> 

#include "scheduler.h"
#include "open.h"
#include "read.h"
#include "statistics.h"

float fcfsPolicy(task_t task_list[], u_int size){
    u_int time = 0;
    u_int i = 0; 
    u_int timeNotUsed = 0;

    while (i < size) {
        if (time >= task_list[i].arrival_time) {
            if (task_list[i].remaining_time == task_list[i].burst_time) {
                task_list[i].start_time = time;
            }

            printf("<time %u> process %u is running\n", time, task_list[i].pid);
            task_list[i].remaining_time--;
            time++;

            if (task_list[i].remaining_time == 0) {
                printf("<time %u> process %u is finished...\n", time, task_list[i].pid);
                task_list[i].finish_time = time;
                i++;
            }
        } else {
            printf("<time %u> system is idle\n", time);
            time++;
            timeNotUsed++;
        }
    }

    printf("<time %u> All processes finished......\n", time);
    return (float)(time - timeNotUsed) / time;
}


// Round Robin Scheduling
float rrPolicy(task_t task_list[], u_int size, u_int quantum) {
    u_int time = 0;
    u_int timeNotUsed = 0;
    u_int finished = 0;
    u_int next_task_index = 0;

    std::queue<u_int> ready_queue;

    while (finished < size) {
        // Add newly arrived tasks to ready queue
        while (next_task_index < size && task_list[next_task_index].arrival_time <= time) {
            ready_queue.push(next_task_index);
            next_task_index++;
        }

        // If no ready task, CPU idle for 1 unit
        if (ready_queue.empty()) {
            printf("<time %u> system is idle\n", time);
            time++;
            timeNotUsed++;
            continue;
        }

        // Get next task from the queue
        u_int idx = ready_queue.front();
        ready_queue.pop();
        task_t &current = task_list[idx];

        // First time this task runs
        if (current.remaining_time == current.burst_time) {
            current.start_time = time;
        }

        // Run for up to quantum or until completion
        u_int run_time = (current.remaining_time < quantum) ? current.remaining_time : quantum;

        for (u_int q = 0; q < run_time; q++) {
            printf("<time %u> process %u is running\n", time, current.pid);
            current.remaining_time--;
            time++;

            // Add any tasks that arrive at this new time
            while (next_task_index < size && task_list[next_task_index].arrival_time <= time) {
                ready_queue.push(next_task_index);
                next_task_index++;
            }

            if (current.remaining_time == 0) {
                break;
            }
        }

        if (current.remaining_time == 0) {
            printf("<time %u> process %u is finished...\n", time, current.pid);
            current.finish_time = time;
            finished++;
        } else {
            // Not finished goes to back of queue
            ready_queue.push(idx);
        }
    }

    printf("<time %u> All processes finished......\n", time);
    return (float)(time - timeNotUsed) / time;
}


/* Shortest Remaining Time First
Using a Min Heap to always access the process with the lowest remaining time
*/
float srtfPolicy(task_t task_list[], u_int size) {
    std::vector<task_t*> ready_queue; 
    
    u_int time = 0;
    u_int timeNotUsed = 0;
    u_int finished_count = 0;
    u_int next_task_index = 0;

    auto comp = [](task_t* a, task_t* b) {
        return a->remaining_time > b->remaining_time;
    };

    while (finished_count < size) {
        while (next_task_index < size &&
               task_list[next_task_index].arrival_time <= time) {
            ready_queue.push_back(&task_list[next_task_index]);
            std::push_heap(ready_queue.begin(), ready_queue.end(), comp);
            next_task_index++;
        }

        if (ready_queue.empty()) {
            printf("<time %u> system is idle\n", time);
            time++;
            timeNotUsed++;
            continue;
        }

        std::pop_heap(ready_queue.begin(), ready_queue.end(), comp);
        task_t* current_task = ready_queue.back();

        if (current_task->remaining_time == current_task->burst_time) {
            current_task->start_time = time;
        }

        printf("<time %u> process %u is running\n", time, current_task->pid);
        current_task->remaining_time--;
        time++;

        if (current_task->remaining_time == 0) {
            printf("<time %u> process %u is finished...\n", time, current_task->pid);
            current_task->finish_time = time;
            finished_count++;
            ready_queue.pop_back();
        } else {
            std::push_heap(ready_queue.begin(), ready_queue.end(), comp);
        }
    }

    printf("<time %u> All processes finished......\n", time);
    return (float)(time - timeNotUsed) / time;
}


int main( int argc, char *argv[] )  {
    char *file_name; 
    FILE *fp; 
    task_t task_array[MAX_TASK_NUM];

    int error_code;
    u_int i;
    u_int count;
    float cpuUsage;

    // CLI Parser
    // ./scheduler <file_name> [FCFS|RR|SRTF] [quantum] 

    //error handling
    if (argc < 3 || argc > 4) {
        printf("Usage: scheduler task_list_file [FCFS|RR|SRTF] [time_quantum]\n");
        return EXIT_FAILURE; 
    }
    if (argc == 3 && strcmp(argv[2], "RR") == 0){
        printf("Usage: input [time_quantum]\n");
        return EXIT_FAILURE;
    }
    if (strcmp(argv[2], "FCFS") != 0 && strcmp(argv[2], "RR") != 0 && strcmp(argv[2], "SRTF") != 0){
        printf("Usage: input valid schedule as shown by [FCFS|RR|SRTF]\n");
        return EXIT_FAILURE;
    }

    error_code = openFile(argv[1], &fp);
    if (error_code == 1)
        return EXIT_FAILURE;

    printf("Scheduling Policy: %s\n", argv[2]);

    read_file(fp, task_array, &count);
    

    printf("There are %d tasks loaded from \"%s\". Press any key to continue ...", count, argv[1]);
    getchar();
    printf("============================================================\n");
    
    if (strcmp(argv[2], "FCFS") == 0){
        cpuUsage = fcfsPolicy(task_array, count);
    }
    else if (strcmp(argv[2], "RR") == 0){
        float rrPolicy(task_t task_list[], u_int size, u_int quantum);
        u_int quantum = (u_int)atoi(argv[3]);
        cpuUsage = rrPolicy(task_array, count, quantum);
    }
    else if (strcmp(argv[2], "SRTF") == 0){
        cpuUsage = srtfPolicy(task_array, count);
    }
    else {
        //edge case
        printf("Invalid scheduling policy\n");
        return EXIT_FAILURE;
    }

    compute_stats(task_array, count, cpuUsage);

    fclose(fp); 
    return EXIT_SUCCESS;
}

    