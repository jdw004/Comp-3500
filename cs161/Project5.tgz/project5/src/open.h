#ifndef _OPEN_H_
#define _OPEN_H_

// Opens a file with the given name and assigns the file descriptor
int openFile(char *name, FILE **file_descriptor);

#endif