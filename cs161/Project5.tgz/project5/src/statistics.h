#ifndef _STATS_H_
#define _STATS_H_

#include "scheduler.h" 


// Computes and displays stats for the given list of tasks
void compute_stats(task_t task_list[], u_int size, float cpu_usage);

#endif