#ifndef _SCHEDULER_H_
#define _SCHEDULER_H_
#define MAX_TASK_NUM 50

typedef unsigned int u_int;

typedef struct task_info {
    u_int pid;
    u_int arrival_time;
    u_int burst_time;

    u_int start_time;
    u_int finish_time;
    u_int remaining_time; 
} task_t;


//first come first serve
float fcfsPolicy(task_t task_list[], u_int size);

//shortest remaining time first
float srtfPolicy(task_t task_list[], u_int size);

//round robin
float rrPolicy(task_t task_list[], u_int size, u_int quantum);


#endif