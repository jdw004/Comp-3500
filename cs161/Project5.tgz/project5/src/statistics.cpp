#include <stdio.h>
#include "scheduler.h"

// Print averages for each statistic
/* Sample output:
============================================================ 
Average waiting time:    22.00 
Average response time:   8.33 
Average turnaround time: 28.83 
Overall CPU usage:       100.00% 
============================================================
*/

// Compute our statistics here
void
compute_stats(task_t task_list[], u_int size, float cpu_usage)
{
    float total_waiting_time = 0;
    float total_response_time = 0;
    float total_turnaround_time = 0;

    for (int i = 0; i < size; i++) {
        task_t task = task_list[i];

        total_waiting_time += task.finish_time - task.arrival_time - task.burst_time;
        total_response_time += task.start_time - task.arrival_time;
        total_turnaround_time += task.finish_time - task.arrival_time;
    }


    float avg_waiting_time = total_waiting_time / size;
    float avg_response_time = total_response_time / size;
    float avg_turnaround_time = total_turnaround_time / size;

    printf("============================================================\n");
    printf("Average waiting time:    %.2f\n", avg_waiting_time);
    printf("Average response time:   %.2f\n", avg_response_time);
    printf("Average turnaround time: %.2f\n", avg_turnaround_time);
    printf("Overall CPU usage:       %.2f%%\n", cpu_usage);
    printf("============================================================\n");
}