#ifndef _READ_H_
#define _READ_H_
#include "scheduler.h"
#include <cstdio>

// Reads tasks from the given file and populates the task_list array
void read_file(FILE *file_descriptor, task_t task_list[], u_int *size);

#endif